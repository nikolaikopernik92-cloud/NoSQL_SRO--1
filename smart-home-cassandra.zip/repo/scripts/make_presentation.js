const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const fa = require("react-icons/fa");
const { applyTheme } = require("/mnt/skills/public/pptx/scripts/apply_theme.js");

const THEME = {
  name: "SmartHomeTelemetry",
  headFontFace: "Cambria",
  bodyFontFace: "Calibri",
  colors: {
    dk1: "0F2A3D", lt1: "FFFFFF", dk2: "1C7293", lt2: "EEF4F7",
    accent1: "F59E0B", accent2: "1C7293", accent3: "5B7C8D",
    accent4: "DC2626", accent5: "0E9F8E", accent6: "475569",
    hlink: "1C7293", folHlink: "5B7C8D",
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9"; // 10 x 5.625
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
pres.title = "Телеметрия умного дома на Apache Cassandra";
pres.author = "СРО, вариант 12";
const C = pres.SchemeColor;

async function icon(Comp, hex) {
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Comp, { color: "#" + hex, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).png().toBuffer();
  return "image/png;base64," + buf.toString("base64");
}

// ---------- layouts ----------
pres.defineSlideMaster({
  title: "COVER", background: { color: C.text1 },
  objects: [{ placeholder: { options: { name: "title", type: "title", x: 0.6, y: 1.15, w: 5.9, h: 1.7, fontSize: 44, bold: true, color: C.background1, valign: "top", align: "left", margin: 0 }, text: "" } }],
});
pres.defineSlideMaster({
  title: "CONTENT", background: { color: C.background1 },
  objects: [{ placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.35, w: 9, h: 0.75, fontSize: 36, bold: true, color: C.text1, valign: "middle", align: "left", margin: 0 }, text: "" } }],
  slideNumber: { x: 9.1, y: 5.2, w: 0.5, h: 0.3, fontSize: 10, color: C.accent6, align: "right" },
});
pres.defineSlideMaster({
  title: "CLOSE", background: { color: C.text1 },
  objects: [{ placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.35, w: 9, h: 0.75, fontSize: 36, bold: true, color: C.background1, valign: "middle", align: "left", margin: 0 }, text: "" } }],
});

const card = (s, x, y, w, h, name) =>
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.12, fill: { color: C.background2 }, line: { color: C.background2, width: 0 }, objectName: name });
const circle = (s, x, y, d, name) =>
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: C.accent1 }, line: { color: C.accent1, width: 0 }, objectName: name });
const T = (s, text, o) => s.addText(text, Object.assign({ isTextBox: true, margin: 0, color: C.text1, valign: "top" }, o));

(async () => {
  const I = {
    bolt: await icon(fa.FaBolt, "0F2A3D"), list: await icon(fa.FaListUl, "0F2A3D"), db: await icon(fa.FaDatabase, "0F2A3D"),
    flask: await icon(fa.FaFlask, "0F2A3D"), target: await icon(fa.FaBullseye, "0F2A3D"), layers: await icon(fa.FaLayerGroup, "0F2A3D"),
    warn: await icon(fa.FaExclamationTriangle, "0F2A3D"), server: await icon(fa.FaServer, "0F2A3D"), branch: await icon(fa.FaCodeBranch, "0F2A3D"),
    clock: await icon(fa.FaClock, "0F2A3D"), gh: await icon(fa.FaGithub, "0F2A3D"), check: await icon(fa.FaCheckCircle, "0F2A3D"),
  };
  const rowIcon = (s, img, x, y, name) => { circle(s, x, y, 0.55, name + "-bg"); s.addImage({ data: img, x: x + 0.14, y: y + 0.14, w: 0.27, h: 0.27, objectName: name }); };

  // 1. Обложка + проблема
  pres.addSection({ title: "Введение" });
  let s = pres.addSlide({ masterName: "COVER", sectionTitle: "Введение" });
  s.addText("Телеметрия умного дома", { placeholder: "title" });
  T(s, "Apache Cassandra · СРО, вариант 12", { x: 0.6, y: 2.9, w: 5.9, h: 0.4, fontSize: 18, color: C.background2 });
  T(s, "Проблема: поток измерений датчиков нужно быстро записывать и читать по устройству и периоду.", { x: 0.6, y: 3.5, w: 5.6, h: 0.9, fontSize: 16, color: C.background1 });
  T(s, "[ФИО студента] · [группа]", { x: 0.6, y: 4.85, w: 5.6, h: 0.3, fontSize: 12, color: C.background2 });
  [["2 023", "измерения"], ["7", "устройств в 3 комнатах"], ["5", "таблиц под запросы"]].forEach(([n, l], i) => {
    const y = 1.2 + i * 1.3;
    T(s, n, { x: 6.9, y, w: 2.6, h: 0.7, fontSize: 40, bold: true, color: C.accent1, fontFace: THEME.headFontFace });
    T(s, l, { x: 6.9, y: y + 0.7, w: 2.6, h: 0.35, fontSize: 14, color: C.background2 });
  });
  s.addNotes("Задача: принимать измерения датчиков умного дома и быстро отдавать их по устройству и периоду. Вариант 12 — Cassandra, таблицы по устройству и временному bucket.");

  // 2. Цель и задачи
  s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Введение" });
  s.addText("Цель и задачи", { placeholder: "title" });
  card(s, 0.5, 1.4, 3.7, 3.5, "goal-card");
  T(s, "Цель", { x: 0.8, y: 1.65, w: 3.1, h: 0.4, fontSize: 20, bold: true, color: C.accent2, fontFace: THEME.headFontFace });
  T(s, "Прототип подсистемы телеметрии на Cassandra: таблицы по устройству и bucket, выборка по периоду, контроль размера партиций.", { x: 0.8, y: 2.15, w: 3.1, h: 2.5, fontSize: 16 });
  [[I.list, "Требования и Access Patterns", "9 FR, 6 NFR, 10 AP"], [I.layers, "Выбор технологии", "сравнение альтернатив, ADR"],
   [I.db, "Модель и код", "5 таблиц, Python, seed 2 023 событий"], [I.flask, "Тесты и демо", "25 тестов, 10 запросов"]].forEach(([img, h, d], i) => {
    const y = 1.4 + i * 0.9;
    rowIcon(s, img, 4.6, y + 0.1, "task-icon-" + i);
    T(s, h, { x: 5.35, y: y + 0.02, w: 4.15, h: 0.4, fontSize: 16, bold: true });
    T(s, d, { x: 5.35, y: y + 0.42, w: 4.15, h: 0.35, fontSize: 14, color: C.accent6 });
  });
  s.addNotes("Четыре блока работы: требования, обоснование технологии, модель с кодом, тесты и демонстрация.");

  // 3. Требования
  s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Введение" });
  s.addText("Требования", { placeholder: "title" });
  [["9", "функциональных"], ["6", "нефункциональных"], ["10", "Access Patterns"]].forEach(([n, l], i) => {
    const x = 0.5 + i * 3.1;
    card(s, x, 1.4, 2.8, 1.5, "stat-card-" + i);
    T(s, n, { x: x + 0.3, y: 1.5, w: 2.2, h: 0.85, fontSize: 48, bold: true, color: C.accent2, fontFace: THEME.headFontFace });
    T(s, l, { x: x + 0.3, y: 2.35, w: 2.3, h: 0.4, fontSize: 16 });
  });
  const reqs = [["Критично", "запись измерения (AP3), текущее состояние (AP6)"], ["Высокий", "период (AP4), последние N (AP5), тревоги (AP8)"],
                ["Нефункц.", "ограничение партиции, TTL 30 дней, воспроизводимость"]];
  reqs.forEach(([h, d], i) => {
    const y = 3.2 + i * 0.62;
    T(s, h, { x: 0.5, y, w: 1.6, h: 0.4, fontSize: 16, bold: true, color: C.accent2 });
    T(s, d, { x: 2.1, y, w: 7.4, h: 0.4, fontSize: 16 });
  });
  s.addNotes("Полный список — в docs/requirements.md. Критичные паттерны: запись измерения и чтение текущего состояния.");

  // 4. Выбор технологии
  pres.addSection({ title: "Решение" });
  s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Решение" });
  s.addText("Почему Cassandra", { placeholder: "title" });
  const rows = [["Вариант", "Оценка для задачи"],
    ["PostgreSQL / Timescale", "Проще, есть JOIN; запись масштабируется вертикально"],
    ["MongoDB time-series", "Удобные агрегации; шардирование требует ключа"],
    ["Redis TimeSeries", "Быстро, но история месяцев хранится в RAM"],
    ["Cassandra", "Линейная запись, TTL, сортировка внутри партиции"]];
  s.addTable(rows.map((r, i) => r.map((c) => ({ text: c, options: {
      bold: i === 0 || r[0] === "Cassandra", fontSize: 14, color: i === 0 ? C.background1 : C.text1,
      fill: { color: i === 0 ? C.text1 : (r[0] === "Cassandra" ? C.accent1 : (i % 2 ? C.background1 : C.background2)) }, valign: "middle" } }))),
    { x: 0.5, y: 1.4, w: 9, colW: [2.9, 6.1], rowH: 0.55, border: { type: "solid", pt: 0.5, color: "D5E1E8" }, margin: [0, 0.12, 0, 0.12], objectName: "alternatives-table" });
  T(s, "Профиль нагрузки — append-only запись и чтение «устройство + период». Для одного дома PostgreSQL проще; Cassandra оправдана при росте числа устройств.", { x: 0.5, y: 4.4, w: 9, h: 0.7, fontSize: 14, color: C.accent6 });
  s.addNotes("ADR-001. Честная оговорка: для одного дома реляционная БД проще. Cassandra выбрана под масштаб платформы и профиль нагрузки.");

  // 5. Модель данных
  s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Решение" });
  s.addText("Модель данных", { placeholder: "title" });
  const tabs = [["measurements_by_device_bucket", "((device_id, bucket), ts DESC)", "история, TTL 30 дней"], ["latest_by_device", "device_id", "текущее состояние"],
    ["devices_by_room", "((home_id, room), device_id)", "устройства комнаты"], ["devices_by_id", "device_id", "поиск и пороги"], ["alerts_by_home_day", "((home_id, day), ts DESC, device_id)", "тревоги за день"]];
  tabs.forEach(([n, pk, d], i) => {
    const col = i % 3, row = Math.floor(i / 3), x = 0.5 + col * 3.1, y = 1.35 + row * 1.75, w = 2.9;
    card(s, x, y, w, 1.55, "table-card-" + i);
    T(s, n, { x: x + 0.1, y: y + 0.12, w: w - 0.2, h: 0.35, fontSize: 10.5, bold: true, fontFace: "Courier New", color: C.accent2 });
    T(s, pk, { x: x + 0.1, y: y + 0.55, w: w - 0.2, h: 0.5, fontSize: 10.5, fontFace: "Courier New" });
    T(s, d, { x: x + 0.1, y: y + 1.12, w: w - 0.2, h: 0.35, fontSize: 14, color: C.accent6 });
  });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 6.7, y: 3.1, w: 2.8, h: 1.55, rectRadius: 0.12, fill: { color: C.accent1 }, line: { color: C.accent1, width: 0 }, objectName: "bucket-callout" });
  T(s, "bucket = день", { x: 6.9, y: 3.22, w: 2.4, h: 0.4, fontSize: 18, bold: true });
  T(s, "96–1 440 строк в партиции — на порядки меньше 100 МБ", { x: 6.9, y: 3.7, w: 2.4, h: 0.85, fontSize: 14 });
  s.addNotes("Принцип: таблица под запрос. Ключ партиции (device_id, bucket) ограничивает её размер, ts DESC даёт последние измерения первыми.");

  // 6. Архитектура
  s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Решение" });
  s.addText("Архитектура", { placeholder: "title" });
  s.addImage({ path: "architecture.png", x: 1.2, y: 1.15, w: 7.6, h: 7.6 * 6.2 / 11, altText: "Схема архитектуры: сервис, репозитории и таблицы Cassandra", objectName: "architecture-diagram" });
  s.addNotes("Сервис не знает о БД: работает через репозиторий. Cassandra-репозиторий — prepared statements; in-memory двойник нужен для тестов без БД.");

  // 7. Реализация
  s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Решение" });
  s.addText("Реализация", { placeholder: "title" });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.5, y: 1.35, w: 5.4, h: 3.65, rectRadius: 0.1, fill: { color: C.text1 }, line: { color: C.text1, width: 0 }, objectName: "code-card" });
  const code = ["def record(self, device_id, ts, value):", "  dev = self.repo.get_device(device_id)", "  bucket = bucket_for(ts, self.gran)", "  self.repo.insert_measurement(", "      device_id, bucket, ts, value)", "  if cur is None or ts >= cur.ts:", "    self.repo.upsert_latest(...)", "  alert = self._check_thresholds(...)", "  if alert:", "    self.repo.insert_alert(alert)"];
  T(s, code.join("\n"), { x: 0.75, y: 1.55, w: 4.95, h: 3.3, fontSize: 14, fontFace: "Courier New", color: C.background1 });
  [[I.server, "Python + cassandra-driver", "prepared statements"], [I.layers, "Сервис и репозиторий", "логика отделена от БД"], [I.branch, "In-memory двойник", "тесты без Cassandra"], [I.bolt, "Docker Compose", "Cassandra 4.1 одной командой"]].forEach(([img, h, d], i) => {
    const y = 1.35 + i * 0.95;
    rowIcon(s, img, 6.2, y + 0.05, "impl-icon-" + i);
    T(s, h, { x: 6.95, y: y + 0.02, w: 2.55, h: 0.4, fontSize: 16, bold: true });
    T(s, d, { x: 6.95, y: y + 0.42, w: 2.55, h: 0.4, fontSize: 14, color: C.accent6 });
  });
  s.addNotes("Запись: bucket, история, upsert текущего состояния без затирания запоздавшими событиями, проверка порогов.");

  // 8. Результаты
  pres.addSection({ title: "Итоги" });
  s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Итоги" });
  s.addText("Результаты", { placeholder: "title" });
  s.addChart(pres.charts.BAR, [{ name: "Строк в партиции", labels: ["15.10", "16.10", "17.10", "18.10"], values: [48, 96, 96, 49] }], {
    x: 0.5, y: 1.3, w: 5.3, h: 3.75, barDir: "col", chartColors: ["1C7293"], showTitle: true, title: "Строк в партиции thermo-living-01 по суткам",
    titleFontSize: 14, titleColor: "0F2A3D", titleFontFace: "+mn-lt", showValue: true, dataLabelPosition: "outEnd", dataLabelFontSize: 12, dataLabelColor: "0F2A3D", dataLabelFontFace: "+mn-lt",
    showLegend: false, catAxisLabelColor: "475569", valAxisLabelColor: "475569", catAxisLabelFontFace: "+mn-lt", valAxisLabelFontFace: "+mn-lt", catAxisLabelFontSize: 12, valAxisLabelFontSize: 12,
    valGridLine: { color: "D5E1E8", size: 0.5 }, catGridLine: { style: "none" }, valAxisMaxVal: 120, objectName: "partition-chart" });
  [["22", "юнит-теста проходят"], ["3", "интеграционных — на живой Cassandra"], ["Q5 · Q6 · Q8", "нетривиальные: через полночь, агрегаты, join в приложении"]].forEach(([n, l], i) => {
    const y = 1.3 + i * 1.3;
    card(s, 6.1, y, 3.4, 1.15, "result-card-" + i);
    T(s, n, { x: 6.3, y: y + 0.1, w: 3.0, h: 0.5, fontSize: i === 2 ? 20 : 28, bold: true, color: C.accent2, fontFace: THEME.headFontFace });
    T(s, l, { x: 6.3, y: y + (i === 2 ? 0.55 : 0.6), w: 3.0, h: 0.55, fontSize: 12 });
  });
  s.addNotes("Партиции 15.10 и 18.10 неполные, 96 строк = 24 часа по 4 измерения. Вывод демо получен на in-memory репозитории; на защите запустить scripts/demo_queries.py на Cassandra.");

  // 9. Ограничения
  s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Итоги" });
  s.addText("Ограничения", { placeholder: "title" });
  [[I.warn, "Запись неатомарна", "несколько таблиц; операции идемпотентны"], [I.target, "Нет JOIN и ad-hoc запросов", "новый запрос — новая таблица"],
   [I.server, "Стенд: 1 узел, RF=1", "отказоустойчивость не проверялась"], [I.flask, "Данные синтетические", "интеграционные тесты нужно запустить на Cassandra"]].forEach(([img, h, d], i) => {
    const col = i % 2, row = Math.floor(i / 2), x = 0.5 + col * 4.6, y = 1.4 + row * 1.85;
    card(s, x, y, 4.4, 1.65, "limit-card-" + i);
    rowIcon(s, img, x + 0.25, y + 0.3, "limit-icon-" + i);
    T(s, h, { x: x + 1.0, y: y + 0.28, w: 3.2, h: 0.65, fontSize: 16, bold: true, valign: "middle" });
    T(s, d, { x: x + 0.25, y: y + 1.0, w: 3.95, h: 0.55, fontSize: 14, color: C.accent6 });
  });
  s.addNotes("Главное ограничение — модель под запрос: аналитика между устройствами выносится за пределы Cassandra.");

  // 10. Выводы
  s = pres.addSlide({ masterName: "CLOSE", sectionTitle: "Итоги" });
  s.addText("Выводы", { placeholder: "title" });
  ["10 Access Patterns закрыты без ALLOW FILTERING", "Партиция ограничена bucket; ts DESC даёт «последние первыми»", "TTL и TWCS убирают ручную очистку", "Цена — денormalизация и отсутствие ad-hoc запросов"].forEach((t, i) => {
    const y = 1.4 + i * 0.75;
    rowIcon(s, I.check, 0.5, y, "conclusion-icon-" + i);
    T(s, t.replace("денormalизация", "денормализация"), { x: 1.25, y: y + 0.05, w: 8.2, h: 0.5, fontSize: 18, color: C.background1, valign: "middle" });
  });
  T(s, "GitHub: [ссылка на репозиторий]", { x: 0.5, y: 4.7, w: 9, h: 0.4, fontSize: 16, bold: true, color: C.accent1 });
  s.addNotes("Итог: модель под запрос с bucket по устройству работает для задачи; цена — денормализация. Ссылка на репозиторий — в README и отчёте.");

  await pres.writeFile({ fileName: "presentation.pptx" });
  await applyTheme("presentation.pptx", THEME);
  console.log("done");
})();
