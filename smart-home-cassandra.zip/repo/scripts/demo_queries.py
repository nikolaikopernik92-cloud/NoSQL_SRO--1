"""Демонстрация запросов.

  python scripts/demo_queries.py                     # на Cassandra (после seed.py)
  python scripts/demo_queries.py --memory            # без Cassandra, на in-memory двойнике
  python scripts/demo_queries.py --memory --anchor 2026-10-18T12:00
"""
import argparse
from datetime import datetime, timezone

import _bootstrap  # noqa: F401
from smart_home import config
from smart_home.demo import run
from smart_home.service import TelemetryService


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--memory", action="store_true", help="использовать in-memory репозиторий")
    ap.add_argument("--anchor", help="опорное время UTC (ISO) для --memory; по умолчанию — сейчас")
    a = ap.parse_args()

    if a.memory:
        from smart_home.memory_repo import InMemoryRepository
        from smart_home.seed_data import generate_readings, make_devices
        svc = TelemetryService(InMemoryRepository(), config.BUCKET_GRANULARITY)
        for d in make_devices():
            svc.register_device(d)
        end = datetime.fromisoformat(a.anchor) if a.anchor else datetime.now(timezone.utc).replace(tzinfo=None)
        for dev, ts, v in generate_readings(end):
            svc.record(dev, ts, v)
        run(svc)
        return

    from smart_home.cassandra_repo import CassandraRepository, connect
    cluster, session = connect(keyspace=config.KEYSPACE)
    try:
        run(TelemetryService(CassandraRepository(session), config.BUCKET_GRANULARITY))
    finally:
        cluster.shutdown()


if __name__ == "__main__":
    main()
