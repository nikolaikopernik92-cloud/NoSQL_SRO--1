"""Создаёт схему и заполняет Cassandra синтетическими данными.

Запуск:  python scripts/seed.py [--days 3] [--step 15] [--reset] [--export-csv data/sample_events.csv]
"""
import argparse
import csv
from datetime import datetime, timezone

import _bootstrap  # noqa: F401
from smart_home import config
from smart_home.seed_data import generate_readings, make_devices
from smart_home.service import TelemetryService


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=3)
    ap.add_argument("--step", type=int, default=15, help="шаг измерений, минут")
    ap.add_argument("--reset", action="store_true", help="удалить keyspace перед созданием")
    ap.add_argument("--export-csv", help="сохранить первые 100 событий в CSV (без записи в БД)")
    a = ap.parse_args()

    readings = generate_readings(datetime.now(timezone.utc).replace(tzinfo=None), a.days, a.step)
    if a.export_csv:
        with open(a.export_csv, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["device_id", "ts_utc", "value"])
            for dev, ts, v in readings[:100]:
                w.writerow([dev, ts.isoformat(), v])
        print(f"exported 100 of {len(readings)} events -> {a.export_csv}")
        return

    from smart_home.cassandra_repo import CassandraRepository, apply_schema, connect  # ленивый импорт

    cluster, session = connect()
    try:
        if a.reset:
            session.execute(f"DROP KEYSPACE IF EXISTS {config.KEYSPACE}")
        apply_schema(session)
        session.set_keyspace(config.KEYSPACE)
        svc = TelemetryService(CassandraRepository(session), config.BUCKET_GRANULARITY)
        for d in make_devices():
            svc.register_device(d)
        alerts = 0
        for dev, ts, v in readings:
            alerts += 1 if svc.record(dev, ts, v) else 0
        print(f"devices: {len(make_devices())}, events: {len(readings)}, alerts: {alerts}")
    finally:
        cluster.shutdown()


if __name__ == "__main__":
    main()
