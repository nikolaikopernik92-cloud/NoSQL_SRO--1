"""Рисует docs/architecture.png (matplotlib)."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

plt.rcParams["font.family"] = "DejaVu Sans"
fig, ax = plt.subplots(figsize=(11, 6.2)); ax.set_xlim(0, 110); ax.set_ylim(0, 62); ax.axis("off")


def box(x, y, w, h, t, fc="#E8F0FE", ec="#1A56DB", fs=9, bold=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.4,rounding_size=1.2", fc=fc, ec=ec, lw=1.4))
    ax.text(x + w / 2, y + h / 2, t, ha="center", va="center", fontsize=fs, fontweight="bold" if bold else "normal")


def arr(x1, y1, x2, y2, rad=0.0):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="->", lw=1.4, color="#334155", connectionstyle=f"arc3,rad={rad}"))


ax.text(55, 60.6, "Архитектура: телеметрия умного дома на Apache Cassandra", ha="center", fontsize=13, fontweight="bold")
box(2, 40, 20, 12, "Датчики / устройства\n(генератор seed_data.py)", fc="#FEF3C7", ec="#B45309")
box(30, 40, 24, 12, "TelemetryService\n(bucket, пороги,\nагрегаты, удаление)", fc="#DCFCE7", ec="#15803D", bold=True)
box(62, 40, 20, 12, "CassandraRepository\n(prepared statements)")
box(88, 40, 20, 12, "InMemoryRepository\n(двойник для тестов)", fc="#F1F5F9", ec="#64748B")
box(30, 22, 24, 10, "CLI-скрипты\nseed.py, demo_queries.py", fc="#FCE7F3", ec="#BE185D")
box(2, 22, 20, 10, "Тесты unittest\n(22 юнит + 3 интегр.)", fc="#F1F5F9", ec="#64748B")
arr(22, 46, 30, 46); arr(54, 46, 62, 46)
arr(46, 52.6, 98, 52.6, rad=-0.12)           # сервис -> in-memory (дугой над репозиторием)
arr(42, 32.4, 42, 39.6)                      # CLI -> сервис
arr(12, 32.4, 33, 39.6, rad=-0.15)           # тесты -> сервис
ax.add_patch(FancyBboxPatch((58, 3), 50, 30, boxstyle="round,pad=0.4,rounding_size=1.5", fc="#EFF6FF", ec="#1D4ED8", lw=2))
ax.text(83, 30, "Cassandra 4.1  ·  keyspace smart_home", ha="center", fontsize=10, fontweight="bold")
tabs = ["measurements_by_device_bucket\nPK ((device_id, bucket), ts DESC) · TTL 30д · TWCS",
        "latest_by_device  ·  PK (device_id)",
        "devices_by_room  ·  PK ((home_id, room), device_id)",
        "devices_by_id  ·  PK (device_id)",
        "alerts_by_home_day  ·  PK ((home_id, day), ts DESC, device_id)"]
for t, y in zip(tabs, [22.5, 18, 13.5, 9, 4.5]):
    two = "\n" in t
    ax.add_patch(FancyBboxPatch((60, y - 0.8 if two else y), 46, 5.2 if two else 3.8,
                                boxstyle="round,pad=0.2,rounding_size=0.8", fc="white", ec="#60A5FA", lw=1))
    ax.text(83, y + 1.8 if two else y + 1.9, t, ha="center", va="center", fontsize=7.6)
arr(72, 39.6, 72, 33.4)
ax.text(3, 12, "Принципы моделирования:\n• таблица под запрос (query-first)\n• partition key ограничивает размер\n  партиции (bucket = день/час)\n"
        "• clustering ts DESC → «последние первыми»\n• денормализация: devices_by_room + devices_by_id\n• запрос по значению без ключа — запрещён",
        fontsize=8.2, va="center")
plt.tight_layout()
out = Path(__file__).resolve().parents[1] / "docs" / "architecture.png"
plt.savefig(out, dpi=170); print("saved", out)
