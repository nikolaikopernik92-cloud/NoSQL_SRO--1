"""Собирает docs/report.pdf (reportlab). Фрагменты кода берутся из исходников."""
import inspect
import re
import sys
import textwrap
from pathlib import Path

import _bootstrap  # noqa: F401
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph, Preformatted,
                                SimpleDocTemplate, Spacer, Table, TableStyle)

from content import AP, FR, NFR
from smart_home.service import TelemetryService

ROOT = Path(__file__).resolve().parents[1]
FD = "/usr/share/fonts/truetype/dejavu/"
pdfmetrics.registerFont(TTFont("DV", FD + "DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("DV-B", FD + "DejaVuSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("DV-I", FD + "DejaVuSans-Oblique.ttf"))
pdfmetrics.registerFont(TTFont("DVM", FD + "DejaVuSansMono.ttf"))
pdfmetrics.registerFontFamily("DV", normal="DV", bold="DV-B", italic="DV-I", boldItalic="DV-B")

ss = getSampleStyleSheet()
BODY = ParagraphStyle("body", parent=ss["Normal"], fontName="DV", fontSize=9.6, leading=14, alignment=TA_JUSTIFY, spaceAfter=5)
H1 = ParagraphStyle("h1", parent=BODY, fontName="DV-B", fontSize=14, leading=18, spaceBefore=10, spaceAfter=6,
                    textColor=colors.HexColor("#1D4ED8"), alignment=0, keepWithNext=1)
H2 = ParagraphStyle("h2", parent=H1, fontSize=11, leading=15, spaceBefore=6, spaceAfter=3, textColor=colors.HexColor("#0F172A"))
CELL = ParagraphStyle("cell", parent=BODY, fontSize=8, leading=10.5, alignment=0, spaceAfter=0)
CELLB = ParagraphStyle("cellb", parent=CELL, fontName="DV-B", textColor=colors.white)
CODE = ParagraphStyle("code", fontName="DVM", fontSize=7.3, leading=9.2, backColor=colors.HexColor("#F1F5F9"),
                      borderPadding=5, spaceBefore=4, spaceAfter=8, leftIndent=4, rightIndent=4)
NOTE = ParagraphStyle("note", parent=BODY, fontName="DV-I", fontSize=8, leading=11, textColor=colors.HexColor("#475569"))
BUL = ParagraphStyle("bul", parent=BODY, leftIndent=14, bulletIndent=3, spaceAfter=2)


def P(t, s=BODY): return Paragraph(t, s)
def bullets(items): return [Paragraph(t, BUL, bulletText="•") for t in items]


def table(rows, widths, header=True):
    data = [[Paragraph(str(c), CELLB if (header and i == 0) else CELL) for c in r] for i, r in enumerate(rows)]
    t = Table(data, colWidths=widths, repeatRows=1 if header else 0)
    st = [("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#CBD5E1")), ("VALIGN", (0, 0), (-1, -1), "TOP"),
          ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]
    if header:
        st += [("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1D4ED8"))]
        st += [("BACKGROUND", (0, i), (-1, i), colors.HexColor("#F8FAFC")) for i in range(2, len(rows), 2)]
    t.setStyle(TableStyle(st))
    return t


def src(obj): return textwrap.dedent(inspect.getsource(obj)).rstrip()


def footer(c, d):
    c.saveState(); c.setFont("DV", 8); c.setFillColor(colors.HexColor("#64748B"))
    c.drawString(2 * cm, 1.2 * cm, "СРО · NoSQL · Вариант 12 · Телеметрия умного дома (Cassandra)")
    c.drawRightString(A4[0] - 2 * cm, 1.2 * cm, f"стр. {d.page}"); c.restoreState()


S = []
# ---------- титул ----------
S += [Spacer(1, 2.2 * cm),
      P("Министерство образования (укажите вуз)", ParagraphStyle("c", parent=BODY, alignment=TA_CENTER)),
      P("Образовательная программа «Информационные системы», 3 курс", ParagraphStyle("c2", parent=BODY, alignment=TA_CENTER)),
      Spacer(1, 3 * cm),
      P("ОТЧЁТ ПО САМОСТОЯТЕЛЬНОЙ РАБОТЕ СТУДЕНТА", ParagraphStyle("t", parent=H1, alignment=TA_CENTER, fontSize=16, leading=21)),
      P("по дисциплине «Проектирование и применение NoSQL-технологий»", ParagraphStyle("c3", parent=BODY, alignment=TA_CENTER, fontSize=11)),
      Spacer(1, 1.2 * cm),
      P("Мини-проект, вариант 12:<br/><b>«Телеметрия умного дома» (Apache Cassandra)</b>",
        ParagraphStyle("c4", parent=BODY, alignment=TA_CENTER, fontSize=13, leading=19)),
      Spacer(1, 4 * cm),
      P("Выполнил: [ФИО студента], группа [группа]<br/>Проверил: [ФИО преподавателя]", ParagraphStyle("c5", parent=BODY, alignment=0, leftIndent=8 * cm)),
      Spacer(1, 3 * cm),
      P("2026", ParagraphStyle("c6", parent=BODY, alignment=TA_CENTER)), PageBreak()]

# ---------- 1. цель ----------
S += [P("1. Цель и постановка задачи", H1),
      P("Цель — спроектировать и реализовать прототип подсистемы хранения телеметрии умного дома на Apache Cassandra: "
        "таблицы по устройству и временному bucket, выборка измерений по периоду, контроль размера партиций."),
      P("Объект — потоки измерений датчиков (температура, влажность, CO<sub>2</sub>, потребляемая мощность). "
        "Нужно принимать измерения, хранить историю 30 дней, выдавать текущее состояние, данные за период и последние N значений, "
        "считать агрегаты и фиксировать выход значений за пороги. Реализация выполнена на Python с драйвером <font name='DVM'>cassandra-driver</font>; "
        "стенд поднимается через Docker Compose."),
      P("Задачи: сформулировать требования и Access Patterns; обосновать выбор СУБД (ADR); спроектировать модель данных; "
        "реализовать код, генерацию синтетических данных, 10 демонстрационных запросов и тесты; оформить репозиторий, отчёт и презентацию.")]

# ---------- 2. требования ----------
S += [P("2. Требования", H1), P("Функциональные требования", H2),
      table([["ID", "Требование"]] + [[i, t] for i, t in FR], [1.6 * cm, 15.4 * cm]),
      Spacer(1, 6), P("Нефункциональные требования", H2),
      table([["ID", "Требование"]] + [[i, t] for i, t in NFR], [1.6 * cm, 15.4 * cm])]

# ---------- 3. AP ----------
S += [P("3. Предметная область и Access Patterns", H1),
      P("Предметная область: дом содержит комнаты; в комнатах установлены устройства, каждое измеряет одну метрику с заданными "
        "порогами. Устройство периодически (в учебной выборке — раз в 15 минут) отправляет пару «время — значение». "
        "Данные неизменяемы; чтение почти всегда ограничено одним устройством и интервалом времени. "
        "Такой профиль соответствует модели «широкая строка во временной партиции»."),
      table([["ID", "Запрос", "Тип", "Приоритет", "Таблица", "Ожидаемый результат"]] +
            [[a, n, t, p, f"<font name='DVM' size='6.2'>{tb.replace(', ', '<br/>')}</font>", r] for a, n, t, p, tb, r in AP],
            [1.2 * cm, 2.6 * cm, 1.8 * cm, 1.9 * cm, 4.2 * cm, 5.3 * cm])]

# ---------- 4. альтернативы + ADR ----------
S += [P("4. Сравнение альтернатив и ADR", H1),
      table([["Вариант", "Плюсы", "Минусы для задачи"],
             ["PostgreSQL / TimescaleDB", "SQL, JOIN, транзакции, простота", "Запись масштабируется вертикально; шардирование сложнее"],
             ["MongoDB time-series", "Агрегации, гибкая схема", "Шардирование требует выбора ключа и балансировки"],
             ["Redis TimeSeries", "Очень низкая задержка", "Объём ограничен RAM; месяцы истории дороги"],
             ["InfluxDB", "Специализирован под метрики", "Кластеризация в OSS ограничена; иная модель запросов"],
             ["<b>Cassandra</b>", "Линейное масштабирование записи, репликация, TTL, сортировка в партиции",
              "Нет JOIN и ad-hoc запросов; модель строится под запросы"]],
            [4 * cm, 6 * cm, 7 * cm]),
      Spacer(1, 6),
      P("<b>ADR-001. Решение:</b> использовать Apache Cassandra и принцип «таблица под запрос». Профиль нагрузки — append-only запись и "
        "чтение «устройство + период» — совпадает с сильными сторонами Cassandra. Альтернативы лучше там, где нужны JOIN, "
        "транзакции или произвольная аналитика."),
      P("<b>Выбор partition key.</b> Ключ <font name='DVM'>(device_id)</font> отклонён: партиция растёт бесконечно. "
        "Ключ <font name='DVM'>(home_id, day)</font> для измерений отклонён: все устройства дома пишут в одну партицию (hot partition). "
        "Принят <font name='DVM'>(device_id, bucket)</font>, где bucket — сутки; при шаге 1 мин это ≈ 1 440 строк в партиции. "
        "Для частых датчиков включается почасовой bucket параметром <font name='DVM'>BUCKET_GRANULARITY=hour</font>."),
      P("<b>Последствия.</b> Запросы вне модели (например, <font name='DVM'>WHERE value &gt; 25</font>) требуют ALLOW FILTERING и не поддерживаются; "
        "запись в несколько таблиц неатомарна; межустройственная аналитика выносится за пределы Cassandra. "
        "Для одного дома с десятком датчиков PostgreSQL/TimescaleDB проще — Cassandra оправдана при масштабе платформы. "
        "Полный текст: <font name='DVM'>docs/ADR.md</font>.")]

# ---------- 5. модель + архитектура ----------
S += [P("5. Схема данных и архитектура", H1),
      Image(str(ROOT / "docs/architecture.png"), width=16.6 * cm, height=16.6 * cm * 6.2 / 11),
      P("Рис. 1. Архитектура прототипа и таблицы keyspace smart_home", NOTE),
      table([["Таблица", "Primary key", "Назначение"],
             ["<font name='DVM'>measurements_by_device_bucket</font>", "<font name='DVM'>((device_id, bucket), ts DESC)</font>",
              "История; TTL 30 дней; TWCS с окном 1 день"],
             ["<font name='DVM'>latest_by_device</font>", "<font name='DVM'>device_id</font>", "Текущее состояние (upsert)"],
             ["<font name='DVM'>devices_by_room</font>", "<font name='DVM'>((home_id, room), device_id)</font>", "Устройства комнаты"],
             ["<font name='DVM'>devices_by_id</font>", "<font name='DVM'>device_id</font>", "Поиск устройства и порогов"],
             ["<font name='DVM'>alerts_by_home_day</font>", "<font name='DVM'>((home_id, day), ts DESC, device_id)</font>", "Тревоги за день"]],
            [5.6 * cm, 6.4 * cm, 5 * cm]),
      Spacer(1, 6),
      P("Оценка размера партиции", H2),
      table([["Частота измерений", "Строк в суточной партиции", "Оценка размера*", "Решение"],
             ["1 раз в 15 мин (учебная выборка)", "96 (проверено тестом)", "≈ 5 КБ", "bucket = день"],
             ["1 раз в минуту", "1 440", "≈ 70 КБ", "bucket = день"],
             ["1 раз в 10 секунд", "8 640", "≈ 430 КБ", "bucket = день"],
             ["1 раз в секунду", "86 400", "≈ 4 МБ", "день допустим; час (3 600 строк, ≈ 180 КБ) удобнее для чтения"]],
            [5 * cm, 4 * cm, 3.2 * cm, 4.8 * cm]),
      P("* Грубая оценка при ≈ 50 байт на строку с учётом служебных данных; фактический размер определяется nodetool tablestats на реальном стенде. "
        "Во всех режимах значения на порядки ниже ориентира в 100 МБ, поэтому суточный bucket подходит по умолчанию, "
        "а почасовой включается параметром без изменения кода запросов.", NOTE)]

# ---------- 6. реализация ----------
rec = src(TelemetryService.record)
per = src(TelemetryService.period)
S += [P("6. Реализация и фрагменты кода", H1),
      P("Код разделён на слои: <font name='DVM'>service.py</font> — бизнес-логика, <font name='DVM'>cassandra_repo.py</font> — доступ к Cassandra "
        "через prepared statements, <font name='DVM'>memory_repo.py</font> — двойник с той же семантикой партиций и сортировки "
        "для тестов без БД. Схема хранится в <font name='DVM'>schema.cql</font>."),
      KeepTogether([P("Запись измерения: вычисляется bucket, обновляются история и текущее состояние, проверяются пороги.", H2),
                    Preformatted(rec, CODE)]),
      KeepTogether([P("Выборка за период: обход bucket от новых к старым; внутри партиции порядок DESC задан CLUSTERING ORDER.", H2),
                    Preformatted(per, CODE)]),
      KeepTogether([P("Основная таблица (фрагмент <font name='DVM'>schema.cql</font>):", H2),
      Preformatted("""CREATE TABLE IF NOT EXISTS measurements_by_device_bucket (
  device_id text, bucket text, ts timestamp, value double,
  PRIMARY KEY ((device_id, bucket), ts)
) WITH CLUSTERING ORDER BY (ts DESC)
  AND default_time_to_live = 2592000
  AND compaction = {'class': 'TimeWindowCompactionStrategy',
                    'compaction_window_unit': 'DAYS', 'compaction_window_size': 1};""", CODE)]),
      KeepTogether([P("Агрегаты считаются самой Cassandra по каждой партиции и объединяются взвешенным средним:", H2),
      Preformatted("""SELECT COUNT(*) AS n, AVG(value) AS avg, MIN(value) AS min, MAX(value) AS max
FROM measurements_by_device_bucket
WHERE device_id=? AND bucket=? AND ts>=? AND ts<=?""", CODE)]),
      P("Соответствие Access Patterns и CQL-запросов", H2),
      table([["AP", "CQL (prepared statement)", "Ключ в WHERE"],
             ["AP2", "SELECT * FROM devices_by_room WHERE home_id=? AND room=?", "вся партиция"],
             ["AP3", "INSERT INTO measurements_by_device_bucket …; INSERT INTO latest_by_device …; INSERT INTO alerts_by_home_day … (при выходе за порог)", "полный PK"],
             ["AP4", "SELECT … FROM measurements_by_device_bucket WHERE device_id=? AND bucket=? AND ts>=? AND ts<=? (по одному запросу на bucket)", "партиция + диапазон clustering"],
             ["AP5", "SELECT … WHERE device_id=? AND bucket=? LIMIT ?", "партиция"],
             ["AP6", "SELECT … FROM latest_by_device WHERE device_id=?", "полный PK"],
             ["AP7", "SELECT COUNT(*), AVG(value), MIN(value), MAX(value) … WHERE device_id=? AND bucket=? AND ts>=? AND ts<=?", "партиция + диапазон"],
             ["AP8", "SELECT … FROM alerts_by_home_day WHERE home_id=? AND day=?", "партиция"],
             ["AP9", "DELETE FROM measurements_by_device_bucket WHERE device_id=? AND bucket=? (по bucket); DELETE из latest_by_device, devices_by_room, devices_by_id", "партиция / PK"],
             ["AP10", "SELECT COUNT(*) … WHERE device_id=? AND bucket=?", "партиция"]],
            [1.2 * cm, 12.2 * cm, 3.6 * cm]),
      Spacer(1, 6),
      P("Данные: скрипт <font name='DVM'>scripts/seed.py</font> создаёт схему, 7 устройств в 3 комнатах и 2 023 синтетических измерения "
        "за 3 суток (детерминированный seed=42, суточная синусоида + шум, около 0,5 % выбросов для проверки тревог). "
        "Образец из 100 событий лежит в <font name='DVM'>data/sample_events.csv</font>. Реальные персональные данные не используются.")]

from smart_home.seed_data import DEVICES  # noqa: E402
S += [P("Устройства синтетического набора", H2),
      table([["device_id", "Комната", "Метрика", "Норма (min…max)"]] +
            [[f"<font name='DVM' size='7'>{d[0]}</font>", d[1], f"{d[3]}, {d[4]}",
              f"{'—' if d[7] is None else d[7]} … {d[8]}"] for d in DEVICES],
            [5.4 * cm, 3 * cm, 4.2 * cm, 4.4 * cm])]

# ---------- 7. запросы ----------
demo = (ROOT / "docs/demo_output.txt").read_text(encoding="utf-8").strip()
demo = re.sub(r"\n{2,}", "\n", demo)
S += [P("7. Запросы и результаты", H1),
      P("Демонстрация состоит из 10 запросов (<font name='DVM'>scripts/demo_queries.py</font>). Нетривиальные: Q5 — период через полночь "
        "(две партиции, сохранение порядка DESC); Q6 — агрегаты за 24 часа по нескольким партициям; Q8 — средняя температура по дням "
        "и комнатам (связь справочника и измерений выполняется в приложении, так как JOIN в Cassandra отсутствует). "
        "Q10 демонстрирует создание, чтение, изменение (upsert по тому же ключу) и удаление."),
      Preformatted(demo, ParagraphStyle("out", parent=CODE, fontSize=6.6, leading=8.3)),
      P("Вывод получен при seed=42 и опорной дате 18.10.2026 12:00 UTC (<font name='DVM'>--memory --anchor 2026-10-18T12:00</font>) на эталонной "
        "in-memory реализации, повторяющей семантику партиций и сортировки. На Cassandra запускайте тот же скрипт без <font name='DVM'>--memory</font>.", NOTE),
      P("Ограничение модели показывают отклонённые запросы: <font name='DVM'>SELECT … WHERE value &gt; 25</font> и поиск измерений по комнате "
        "без указания устройства не принимаются Cassandra без ALLOW FILTERING — для них нужны отдельные таблицы под запрос.")]

# ---------- 8. тестирование ----------
S += [P("8. Тестирование", H1),
      P("Всего 25 тестов (<font name='DVM'>unittest</font>): 22 юнит-теста бизнес-логики на in-memory репозитории, "
        "3 интеграционных теста на живой Cassandra (отдельный keyspace <font name='DVM'>smart_home_test</font>)."),
      table([["№", "Сценарий", "Проверка"],
             ["1", "Период через полночь", "9 строк из двух партиций, порядок DESC; режим ASC"],
             ["2", "Агрегаты по партициям", "count/avg/min/max совпадают с ручным расчётом; пустой период даёт count=0"],
             ["3", "Последние N", "60 записей собираются из 2 партиций, самая новая — первая"],
             ["4", "Тревога по порогу", "значение выше max / ниже min создаёт запись в alerts; норма — не создаёт"],
             ["5", "Запоздавшее событие", "current не затирается более старой записью"],
             ["6", "Upsert по PK", "повторная запись с тем же ts заменяет значение"],
             ["7", "Удаление устройства", "очищены измерения, current и справочники"],
             ["8", "Часовой bucket", "4 записи в партиции; период и last_n корректны"],
             ["+", "Граничные случаи", "неизвестное устройство, неверный диапазон, неизвестная гранулярность"]],
            [0.9 * cm, 4.6 * cm, 11.5 * cm]),
      Spacer(1, 6),
      P("Результат запуска юнит-тестов: <font name='DVM'>Ran 25 tests … OK (skipped=3)</font> — три пропуска — интеграционные тесты без "
        "<font name='DVM'>RUN_INTEGRATION=1</font>. Интеграционные тесты проверяют ту же логику на реальных CQL-запросах (сортировка партиции, "
        "CQL-агрегаты, запись тревог).")]

S += [P("Запуск и воспроизводимость", H2),
      Preformatted("""cp .env.example .env
docker compose up -d
pip install -r requirements.txt
python scripts/seed.py --reset
python scripts/demo_queries.py
python -m unittest discover -s tests -t . -v
RUN_INTEGRATION=1 python -m unittest tests.test_integration -v""", CODE),
      P("В репозитории нет секретов: <font name='DVM'>.env.example</font> содержит только адрес, порт, имя keyspace и гранулярность bucket; "
        "<font name='DVM'>.env</font> исключён через <font name='DVM'>.gitignore</font>.")]

S += [P("Консистентность и эксплуатация", H2),
      P("<b>Уровни согласованности.</b> Для телеметрии допустима запись с уровнем <font name='DVM'>ONE</font>/<font name='DVM'>LOCAL_ONE</font>: "
        "потеря единичного измерения при сбое узла приемлема, а запись остаётся быстрой. Чтение текущего состояния и тревог в промышленной схеме "
        "(RF=3) разумно выполнять с <font name='DVM'>LOCAL_QUORUM</font>. В прототипе (один узел) используется уровень драйвера по умолчанию, "
        "поэтому поведение при отказах и расхождении реплик здесь не проверялось."),
      P("<b>Идемпотентность.</b> Все вставки — upsert по первичному ключу: повторная отправка того же измерения не создаёт дубликата. "
        "Это позволяет безопасно повторять запись после таймаута, а запоздавшие события не затирают <font name='DVM'>latest_by_device</font>."),
      P("<b>Мониторинг.</b> Размер и рост партиций проверяются командами <font name='DVM'>nodetool tablestats</font> и "
        "<font name='DVM'>nodetool tablehistograms</font>; в прототипе для этого есть функция <font name='DVM'>partition_size()</font> (запрос Q9). "
        "Признаки проблем: партиции больше ориентира, рост числа tombstone, задержки чтения в одной партиции. "
        "Срок хранения (30 дней) и размер окна компактизации согласованы: окно в 1 день создаёт примерно 30 групп SSTable, "
        "истекающих целиком.")]

# ---------- 9. ограничения + выводы ----------
S += [P("9. Ограничения", H1)] + bullets([
    "Запись в несколько таблиц неатомарна; сбой между вставками возможен. Операции идемпотентны, повтор безопасен; для строгой согласованности нужен LOGGED BATCH или фоновая сверка.",
    "<font name='DVM'>record()</font> читает справочник и текущее состояние перед записью (чтение по первичному ключу, но не «чистая» запись).",
    "Удаления создают tombstone; массовое удаление устройства за длинный период нужно планировать.",
    "<font name='DVM'>COUNT(*)</font> по партиции читает все её строки — для мониторинга размера подходит, для горячего пути нет.",
    "Аналитика между устройствами и произвольные фильтры не поддерживаются моделью; для них требуется отдельный аналитический контур.",
    "Стенд одноузловой, RF=1: отказоустойчивость и tunable consistency не проверялись; данные синтетические."])
S += [P("10. Выводы", H1)] + bullets([
    "Модель «таблица под запрос» с partition key (device_id, bucket) закрывает 10 Access Patterns без ALLOW FILTERING; размер партиции контролируется настройкой bucket.",
    "Clustering order ts DESC делает чтение «последних N» и «текущего состояния» обращением к одной партиции или строке.",
    "TTL и TimeWindowCompactionStrategy снимают задачу очистки: истёкшие данные уходят целыми SSTable.",
    "Цена решения — денормализация и отсутствие ad-hoc запросов; для малых объёмов реляционная СУБД проще, Cassandra оправдана при росте нагрузки и числа устройств.",
    "Разделение на сервис и репозиторий позволило проверить логику без БД и оставить единые демонстрационные запросы для обоих режимов."])
S += [P("11. Ссылка на GitHub", H1), P("[вставьте ссылку на репозиторий] — README, исходники, тестовые данные, ADR, отчёт и презентация.")]

doc = SimpleDocTemplate(str(ROOT / "docs/report.pdf"), pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm,
                        topMargin=1.8 * cm, bottomMargin=2 * cm,
                        title="СРО · Телеметрия умного дома (Cassandra)", author="Вариант 12")
doc.build(S, onFirstPage=lambda c, d: None, onLaterPages=footer)
from pypdf import PdfReader
print("pages:", len(PdfReader(str(ROOT / "docs/report.pdf")).pages))
