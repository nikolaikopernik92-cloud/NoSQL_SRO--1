"""Генератор синтетических данных (детерминированный, без реальных персональных данных)."""
import math
import random
from datetime import datetime, timedelta

from .models import Device

HOME = "home-1"

DEVICES = [
    # device_id, room, dtype, metric, unit, base, amplitude, min, max
    ("thermo-living-01", "living", "thermostat", "temperature", "°C", 22.0, 2.0, 16.0, 28.0),
    ("hum-living-01", "living", "hygrometer", "humidity", "%", 45.0, 8.0, 25.0, 70.0),
    ("thermo-bedroom-01", "bedroom", "thermostat", "temperature", "°C", 20.0, 2.0, 16.0, 28.0),
    ("co2-bedroom-01", "bedroom", "co2_sensor", "co2", "ppm", 700.0, 250.0, None, 1200.0),
    ("thermo-kitchen-01", "kitchen", "thermostat", "temperature", "°C", 23.0, 2.5, 16.0, 30.0),
    ("power-kitchen-01", "kitchen", "power_meter", "power", "W", 600.0, 400.0, None, 3000.0),
    ("fridge-kitchen-01", "kitchen", "thermostat", "temperature", "°C", 4.0, 1.0, 0.0, 7.0),
]


def make_devices() -> list[Device]:
    return [Device(d[0], HOME, d[1], d[2], d[3], d[4], d[7], d[8]) for d in DEVICES]


def generate_readings(end: datetime, days: int = 3, step_minutes: int = 15, seed: int = 42):
    """Возвращает отсортированный по времени список (device_id, ts, value).

    ~0.5% значений — выбросы за пределами порогов (для проверки тревог).
    """
    rnd = random.Random(seed)
    end = end.replace(second=0, microsecond=0, minute=(end.minute // step_minutes) * step_minutes)
    n = days * 24 * 60 // step_minutes
    out = []
    for i in range(n + 1):
        ts = end - timedelta(minutes=step_minutes * (n - i))
        hour = ts.hour + ts.minute / 60
        for (dev_id, _room, _t, metric, _u, base, amp, lo, hi) in DEVICES:
            phase = math.sin(2 * math.pi * (hour - 9) / 24)
            v = base + amp * phase + rnd.gauss(0, amp * 0.1)
            if rnd.random() < 0.005:                       # аномалия
                v = (hi + abs(amp)) if hi is not None else base + 4 * amp
            out.append((dev_id, ts, round(max(v, 0.0), 2)))
    return out
