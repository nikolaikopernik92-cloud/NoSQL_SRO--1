"""Бизнес-логика: запись телеметрии, выборки по периоду, агрегаты, удаление."""
from datetime import datetime, timedelta
from typing import Optional

from .bucket import bucket_for, buckets_between
from .models import Alert, Device, Measurement


class TelemetryService:
    def __init__(self, repo, granularity: str = "day"):
        self.repo = repo
        self.gran = granularity

    # AP1
    def register_device(self, device: Device) -> None:
        self.repo.add_device(device)

    # AP2
    def devices_in_room(self, home_id: str, room: str) -> list[Device]:
        return self.repo.devices_in_room(home_id, room)

    # AP3: запись измерения + обновление latest + проверка порогов
    def record(self, device_id: str, ts: datetime, value: float) -> Optional[Alert]:
        dev = self.repo.get_device(device_id)
        if dev is None:
            raise KeyError(f"unknown device: {device_id}")
        self.repo.insert_measurement(device_id, bucket_for(ts, self.gran), ts, value)
        cur = self.repo.get_latest(device_id)
        if cur is None or ts >= cur.ts:          # не затираем свежие данные опоздавшими
            self.repo.upsert_latest(device_id, ts, value)
        alert = self._check_thresholds(dev, ts, value)
        if alert:
            self.repo.insert_alert(alert)
        return alert

    @staticmethod
    def _check_thresholds(dev: Device, ts: datetime, value: float) -> Optional[Alert]:
        msg = None
        if dev.max_value is not None and value > dev.max_value:
            msg = f"{dev.metric} {value:.1f}{dev.unit} выше порога {dev.max_value}{dev.unit}"
        elif dev.min_value is not None and value < dev.min_value:
            msg = f"{dev.metric} {value:.1f}{dev.unit} ниже порога {dev.min_value}{dev.unit}"
        if msg is None:
            return None
        return Alert(dev.home_id, ts.strftime("%Y-%m-%d"), ts, dev.device_id, value, msg)

    # AP4: измерения за период (может пересекать несколько партиций)
    def period(self, device_id: str, start: datetime, end: datetime,
               newest_first: bool = True) -> list[Measurement]:
        buckets = buckets_between(start, end, self.gran)
        out: list[Measurement] = []
        for b in reversed(buckets):              # каждая партиция уже DESC
            out.extend(self.repo.measurements_in_bucket(device_id, b, start, end))
        return out if newest_first else out[::-1]

    # AP5: последние N измерений (идём назад по bucket до набора N)
    def last_n(self, device_id: str, n: int, now: datetime, max_lookback: int = 31) -> list[Measurement]:
        out: list[Measurement] = []
        cur = now
        step = timedelta(days=1) if self.gran == "day" else timedelta(hours=1)
        for _ in range(max_lookback):
            out.extend(self.repo.last_in_bucket(device_id, bucket_for(cur, self.gran), n - len(out)))
            if len(out) >= n:
                break
            cur -= step
        return out

    # AP6
    def current(self, device_id: str) -> Optional[Measurement]:
        return self.repo.get_latest(device_id)

    # AP7: агрегаты за период (CQL COUNT/AVG/MIN/MAX по каждой партиции + объединение)
    def stats(self, device_id: str, start: datetime, end: datetime) -> dict:
        total, wsum, vmin, vmax = 0, 0.0, None, None
        for b in buckets_between(start, end, self.gran):
            n, avg, mn, mx = self.repo.aggregate_in_bucket(device_id, b, start, end)
            if n == 0:
                continue
            total += n
            wsum += avg * n
            vmin = mn if vmin is None else min(vmin, mn)
            vmax = mx if vmax is None else max(vmax, mx)
        return {"count": total, "avg": (wsum / total if total else None), "min": vmin, "max": vmax}

    # AP8
    def alerts_for_day(self, home_id: str, day: str) -> list[Alert]:
        return self.repo.alerts(home_id, day)

    # Мониторинг размера партиции (контроль hot/large partitions)
    def partition_size(self, device_id: str, bucket: str) -> int:
        return self.repo.count_in_bucket(device_id, bucket)

    # AP9: удаление устройства и всех его партиций за период хранения
    def delete_device(self, device_id: str, since: datetime, until: datetime) -> int:
        dev = self.repo.get_device(device_id)
        if dev is None:
            return 0
        buckets = buckets_between(since, until, self.gran)
        for b in buckets:
            self.repo.delete_bucket(device_id, b)
        self.repo.delete_latest(device_id)
        self.repo.delete_device_rows(dev)
        return len(buckets)
