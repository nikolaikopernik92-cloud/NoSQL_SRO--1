from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass(frozen=True)
class Device:
    device_id: str
    home_id: str
    room: str
    dtype: str
    metric: str
    unit: str
    min_value: Optional[float] = None
    max_value: Optional[float] = None


@dataclass(frozen=True)
class Measurement:
    device_id: str
    ts: datetime
    value: float


@dataclass(frozen=True)
class Alert:
    home_id: str
    day: str
    ts: datetime
    device_id: str
    value: float
    message: str
