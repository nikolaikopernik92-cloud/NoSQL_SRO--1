"""Демонстрационные запросы (10 шт., из них 3 нетривиальных) и CRUD-цикл.

run(svc) работает с любым репозиторием: Cassandra или in-memory.
"""
from datetime import datetime, timedelta

from .bucket import bucket_for
from .models import Device
from .seed_data import HOME


def title(n, text):
    print(f"\n=== Q{n}. {text}")


def run(svc) -> None:
    thermo = "thermo-living-01"
    now = svc.current(thermo).ts            # «сейчас» = время последнего измерения
    midnight = now.replace(hour=0, minute=0)

    title(1, "Устройства в комнате kitchen (AP2)")
    for d in svc.devices_in_room(HOME, "kitchen"):
        print(f"  {d.device_id:20} {d.metric:12} [{d.min_value}..{d.max_value}] {d.unit}")

    title(2, "Текущее состояние холодильника (AP6)")
    m = svc.current("fridge-kitchen-01")
    print(f"  {m.ts:%Y-%m-%d %H:%M} -> {m.value}")

    title(3, "Последние 5 измерений термостата гостиной (AP5)")
    for m in svc.last_n(thermo, 5, now):
        print(f"  {m.ts:%Y-%m-%d %H:%M}  {m.value}")

    title(4, "Измерения за 2 часа в пределах одной партиции (AP4)")
    rows = svc.period(thermo, midnight, midnight + timedelta(hours=2))
    print(f"  строк: {len(rows)}, первая: {rows[0].ts:%H:%M}, последняя: {rows[-1].ts:%H:%M}")

    title(5, "НЕТРИВИАЛЬНЫЙ: период через полночь (2 партиции, порядок DESC) (AP4)")
    rows = svc.period(thermo, midnight - timedelta(hours=1), midnight + timedelta(hours=1))
    print(f"  партиции: {sorted({bucket_for(r.ts, svc.gran) for r in rows})}, строк: {len(rows)}")
    print("  " + ", ".join(f"{r.ts:%d %H:%M}" for r in rows))

    title(6, "НЕТРИВИАЛЬНЫЙ: агрегаты за 24 часа (CQL COUNT/AVG/MIN/MAX по партициям) (AP7)")
    st = svc.stats(thermo, now - timedelta(hours=24), now)
    print(f"  count={st['count']} avg={st['avg']:.2f} min={st['min']} max={st['max']}")

    title(7, "Тревоги за сегодня и вчера (AP8)")
    for day in (now, now - timedelta(days=1)):
        for a in svc.alerts_for_day(HOME, day.strftime("%Y-%m-%d")):
            print(f"  {a.ts:%Y-%m-%d %H:%M} {a.device_id:20} {a.message}")

    title(8, "НЕТРИВИАЛЬНЫЙ: средняя температура по дням и комнатам (join на стороне приложения)")
    for room in ("living", "bedroom", "kitchen"):
        temps = [d for d in svc.devices_in_room(HOME, room) if d.metric == "temperature"]
        for d in temps:
            cells = []
            for k in (2, 1, 0):
                day0 = (now - timedelta(days=k)).replace(hour=0, minute=0)
                s = svc.stats(d.device_id, day0, day0 + timedelta(hours=23, minutes=59))
                cells.append(f"{day0:%m-%d}: {s['avg']:.1f}" if s["count"] else f"{day0:%m-%d}: -")
            print(f"  {room:8} {d.device_id:20} " + " | ".join(cells))

    title(9, "Размер партиций (контроль large partition)")
    for k in (2, 1, 0):
        b = bucket_for(now - timedelta(days=k), svc.gran)
        print(f"  ({thermo}, {b}): {svc.partition_size(thermo, b)} строк")

    title(10, "CRUD-цикл: создание → чтение → изменение → удаление")
    dev = Device("demo-temp-99", HOME, "garage", "thermostat", "temperature", "°C", 5.0, 30.0)
    svc.register_device(dev)
    ts = now + timedelta(minutes=1)
    alert = svc.record(dev.device_id, ts, 35.0)
    print(f"  C: записано 35.0, тревога: {alert.message if alert else None}")
    print(f"  R: current = {svc.current(dev.device_id).value}")
    svc.record(dev.device_id, ts, 21.5)           # тот же PK -> перезапись (UPDATE = upsert)
    rows = svc.period(dev.device_id, ts, ts)
    print(f"  U: после перезаписи значение = {rows[0].value}")
    n = svc.delete_device(dev.device_id, ts - timedelta(days=1), ts + timedelta(days=1))
    print(f"  D: удалено партиций: {n}, current = {svc.current(dev.device_id)}")
