"""Реализация репозитория поверх Apache Cassandra (cassandra-driver)."""
import re
from datetime import datetime
from typing import Optional

from cassandra.cluster import Cluster

from . import config
from .models import Alert, Device, Measurement


def apply_schema(session, keyspace: str = config.KEYSPACE, schema_file=config.SCHEMA_FILE) -> None:
    """Выполняет schema.cql (разбор по ';', комментарии '--' отбрасываются).

    Имя keyspace подставляется вместо 'smart_home' (нужно для изолированных тестов).
    """
    text = re.sub(r"--[^\n]*", "", schema_file.read_text(encoding="utf-8"))
    text = text.replace("smart_home", keyspace)
    for stmt in (s.strip() for s in text.split(";")):
        if stmt:
            session.execute(stmt)


def connect(host=config.CASSANDRA_HOST, port=config.CASSANDRA_PORT,
            keyspace: Optional[str] = None):
    cluster = Cluster([host], port=port)
    return cluster, cluster.connect(keyspace)


class CassandraRepository:
    def __init__(self, session):
        self.s = session
        p = session.prepare
        self._ins_dev_room = p(
            "INSERT INTO devices_by_room (home_id, room, device_id, dtype, metric, unit, min_value, max_value) "
            "VALUES (?,?,?,?,?,?,?,?)")
        self._ins_dev_id = p(
            "INSERT INTO devices_by_id (device_id, home_id, room, dtype, metric, unit, min_value, max_value) "
            "VALUES (?,?,?,?,?,?,?,?)")
        self._sel_dev_room = p(
            "SELECT * FROM devices_by_room WHERE home_id=? AND room=?")
        self._sel_dev_id = p("SELECT * FROM devices_by_id WHERE device_id=?")
        self._ins_meas = p(
            "INSERT INTO measurements_by_device_bucket (device_id, bucket, ts, value) VALUES (?,?,?,?)")
        self._sel_range = p(
            "SELECT device_id, ts, value FROM measurements_by_device_bucket "
            "WHERE device_id=? AND bucket=? AND ts>=? AND ts<=?")
        self._sel_last = p(
            "SELECT device_id, ts, value FROM measurements_by_device_bucket "
            "WHERE device_id=? AND bucket=? LIMIT ?")
        self._sel_agg = p(
            "SELECT COUNT(*) AS n, AVG(value) AS avg, MIN(value) AS min, MAX(value) AS max "
            "FROM measurements_by_device_bucket WHERE device_id=? AND bucket=? AND ts>=? AND ts<=?")
        self._count_bucket = p(
            "SELECT COUNT(*) AS n FROM measurements_by_device_bucket WHERE device_id=? AND bucket=?")
        self._upd_latest = p("INSERT INTO latest_by_device (device_id, ts, value) VALUES (?,?,?)")
        self._sel_latest = p("SELECT device_id, ts, value FROM latest_by_device WHERE device_id=?")
        self._ins_alert = p(
            "INSERT INTO alerts_by_home_day (home_id, day, ts, device_id, value, message) VALUES (?,?,?,?,?,?)")
        self._sel_alerts = p(
            "SELECT home_id, day, ts, device_id, value, message FROM alerts_by_home_day WHERE home_id=? AND day=?")
        self._del_bucket = p(
            "DELETE FROM measurements_by_device_bucket WHERE device_id=? AND bucket=?")
        self._del_latest = p("DELETE FROM latest_by_device WHERE device_id=?")
        self._del_dev_room = p("DELETE FROM devices_by_room WHERE home_id=? AND room=? AND device_id=?")
        self._del_dev_id = p("DELETE FROM devices_by_id WHERE device_id=?")

    # --- devices ---
    def add_device(self, d: Device) -> None:
        args = (d.device_id, d.home_id, d.room, d.dtype, d.metric, d.unit, d.min_value, d.max_value)
        self.s.execute(self._ins_dev_room, (d.home_id, d.room, d.device_id, d.dtype, d.metric, d.unit,
                                            d.min_value, d.max_value))
        self.s.execute(self._ins_dev_id, args)

    @staticmethod
    def _dev(r) -> Device:
        return Device(r.device_id, r.home_id, r.room, r.dtype, r.metric, r.unit, r.min_value, r.max_value)

    def devices_in_room(self, home_id: str, room: str) -> list[Device]:
        return sorted((self._dev(r) for r in self.s.execute(self._sel_dev_room, (home_id, room))),
                      key=lambda d: d.device_id)

    def get_device(self, device_id: str) -> Optional[Device]:
        r = self.s.execute(self._sel_dev_id, (device_id,)).one()
        return self._dev(r) if r else None

    # --- measurements ---
    def insert_measurement(self, device_id: str, bucket: str, ts: datetime, value: float) -> None:
        self.s.execute(self._ins_meas, (device_id, bucket, ts, value))

    def measurements_in_bucket(self, device_id, bucket, start, end) -> list[Measurement]:
        """Порядок — DESC (задан CLUSTERING ORDER)."""
        return [Measurement(r.device_id, r.ts, r.value)
                for r in self.s.execute(self._sel_range, (device_id, bucket, start, end))]

    def last_in_bucket(self, device_id, bucket, limit) -> list[Measurement]:
        return [Measurement(r.device_id, r.ts, r.value)
                for r in self.s.execute(self._sel_last, (device_id, bucket, limit))]

    def aggregate_in_bucket(self, device_id, bucket, start, end):
        r = self.s.execute(self._sel_agg, (device_id, bucket, start, end)).one()
        return (r.n, r.avg, r.min, r.max) if r.n else (0, None, None, None)

    def count_in_bucket(self, device_id, bucket) -> int:
        return self.s.execute(self._count_bucket, (device_id, bucket)).one().n

    def delete_bucket(self, device_id, bucket) -> None:
        self.s.execute(self._del_bucket, (device_id, bucket))

    # --- latest ---
    def upsert_latest(self, device_id, ts, value) -> None:
        self.s.execute(self._upd_latest, (device_id, ts, value))

    def get_latest(self, device_id) -> Optional[Measurement]:
        r = self.s.execute(self._sel_latest, (device_id,)).one()
        return Measurement(r.device_id, r.ts, r.value) if r else None

    def delete_latest(self, device_id) -> None:
        self.s.execute(self._del_latest, (device_id,))

    def delete_device_rows(self, d: Device) -> None:
        self.s.execute(self._del_dev_room, (d.home_id, d.room, d.device_id))
        self.s.execute(self._del_dev_id, (d.device_id,))

    # --- alerts ---
    def insert_alert(self, a: Alert) -> None:
        self.s.execute(self._ins_alert, (a.home_id, a.day, a.ts, a.device_id, a.value, a.message))

    def alerts(self, home_id, day) -> list[Alert]:
        return [Alert(r.home_id, r.day, r.ts, r.device_id, r.value, r.message)
                for r in self.s.execute(self._sel_alerts, (home_id, day))]
