"""Вычисление временных bucket (часть partition key)."""
from datetime import datetime, timedelta

FORMATS = {"day": "%Y-%m-%d", "hour": "%Y-%m-%dT%H"}
STEPS = {"day": timedelta(days=1), "hour": timedelta(hours=1)}


def _floor(ts: datetime, gran: str) -> datetime:
    if gran == "day":
        return ts.replace(hour=0, minute=0, second=0, microsecond=0)
    if gran == "hour":
        return ts.replace(minute=0, second=0, microsecond=0)
    raise ValueError(f"unknown granularity: {gran}")


def bucket_for(ts: datetime, gran: str = "day") -> str:
    """Bucket, которому принадлежит момент ts (naive UTC)."""
    return _floor(ts, gran).strftime(FORMATS[gran])


def buckets_between(start: datetime, end: datetime, gran: str = "day") -> list[str]:
    """Все bucket, пересекающие [start, end], по возрастанию."""
    if end < start:
        raise ValueError("end must be >= start")
    cur, last = _floor(start, gran), _floor(end, gran)
    out = []
    while cur <= last:
        out.append(cur.strftime(FORMATS[gran]))
        cur += STEPS[gran]
    return out
