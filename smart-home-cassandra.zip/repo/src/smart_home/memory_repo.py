"""In-memory двойник репозитория с той же семантикой партиций и сортировки.

Нужен, чтобы юнит-тесты бизнес-логики выполнялись без запущенной Cassandra.
Partition = ключ словаря, внутри партиции строки отсортированы по ts DESC.
"""
from datetime import datetime
from typing import Optional

from .models import Alert, Device, Measurement


class InMemoryRepository:
    def __init__(self):
        self.dev_by_id: dict[str, Device] = {}
        self.dev_by_room: dict[tuple, dict[str, Device]] = {}
        self.meas: dict[tuple, dict[datetime, float]] = {}
        self.latest: dict[str, Measurement] = {}
        self.alert_parts: dict[tuple, dict[tuple, Alert]] = {}

    def add_device(self, d: Device) -> None:
        self.dev_by_id[d.device_id] = d
        self.dev_by_room.setdefault((d.home_id, d.room), {})[d.device_id] = d

    def devices_in_room(self, home_id, room):
        return sorted(self.dev_by_room.get((home_id, room), {}).values(), key=lambda d: d.device_id)

    def get_device(self, device_id) -> Optional[Device]:
        return self.dev_by_id.get(device_id)

    def insert_measurement(self, device_id, bucket, ts, value):
        self.meas.setdefault((device_id, bucket), {})[ts] = value  # upsert по PK

    def _rows(self, device_id, bucket):
        part = self.meas.get((device_id, bucket), {})
        return [Measurement(device_id, t, part[t]) for t in sorted(part, reverse=True)]

    def measurements_in_bucket(self, device_id, bucket, start, end):
        return [m for m in self._rows(device_id, bucket) if start <= m.ts <= end]

    def last_in_bucket(self, device_id, bucket, limit):
        return self._rows(device_id, bucket)[:limit]

    def aggregate_in_bucket(self, device_id, bucket, start, end):
        v = [m.value for m in self.measurements_in_bucket(device_id, bucket, start, end)]
        return (len(v), sum(v) / len(v), min(v), max(v)) if v else (0, None, None, None)

    def count_in_bucket(self, device_id, bucket):
        return len(self.meas.get((device_id, bucket), {}))

    def delete_bucket(self, device_id, bucket):
        self.meas.pop((device_id, bucket), None)

    def upsert_latest(self, device_id, ts, value):
        self.latest[device_id] = Measurement(device_id, ts, value)

    def get_latest(self, device_id):
        return self.latest.get(device_id)

    def delete_latest(self, device_id):
        self.latest.pop(device_id, None)

    def delete_device_rows(self, d: Device):
        self.dev_by_id.pop(d.device_id, None)
        self.dev_by_room.get((d.home_id, d.room), {}).pop(d.device_id, None)

    def insert_alert(self, a: Alert):
        self.alert_parts.setdefault((a.home_id, a.day), {})[(a.ts, a.device_id)] = a

    def alerts(self, home_id, day):
        part = self.alert_parts.get((home_id, day), {})
        keys = sorted(part, key=lambda k: (-k[0].timestamp(), k[1]))  # ts DESC, device_id ASC
        return [part[k] for k in keys]
