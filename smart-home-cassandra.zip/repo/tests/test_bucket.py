import unittest
from datetime import datetime

from tests import _path  # noqa: F401
from smart_home.bucket import bucket_for, buckets_between


class BucketTests(unittest.TestCase):
    def test_day_bucket(self):
        self.assertEqual(bucket_for(datetime(2026, 10, 18, 23, 59, 59)), "2026-10-18")

    def test_hour_bucket(self):
        self.assertEqual(bucket_for(datetime(2026, 10, 18, 7, 5), "hour"), "2026-10-18T07")

    def test_range_crossing_midnight(self):
        r = buckets_between(datetime(2026, 10, 17, 23, 0), datetime(2026, 10, 18, 1, 0))
        self.assertEqual(r, ["2026-10-17", "2026-10-18"])

    def test_range_hours(self):
        r = buckets_between(datetime(2026, 10, 18, 22, 30), datetime(2026, 10, 19, 0, 10), "hour")
        self.assertEqual(r, ["2026-10-18T22", "2026-10-18T23", "2026-10-19T00"])

    def test_invalid_range(self):
        with self.assertRaises(ValueError):
            buckets_between(datetime(2026, 10, 18), datetime(2026, 10, 17))

    def test_unknown_granularity(self):
        with self.assertRaises(ValueError):
            bucket_for(datetime(2026, 1, 1), "week")


if __name__ == "__main__":
    unittest.main()
