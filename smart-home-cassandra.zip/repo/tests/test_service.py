"""Тестовые сценарии бизнес-логики на in-memory репозитории (Cassandra не нужна)."""
import unittest
from datetime import datetime, timedelta

from tests import _path  # noqa: F401
from smart_home.bucket import bucket_for
from smart_home.memory_repo import InMemoryRepository
from smart_home.models import Device
from smart_home.seed_data import HOME, generate_readings, make_devices
from smart_home.service import TelemetryService

END = datetime(2026, 10, 18, 12, 0)
THERMO = "thermo-living-01"


def build(gran="day"):
    svc = TelemetryService(InMemoryRepository(), gran)
    for d in make_devices():
        svc.register_device(d)
    readings = generate_readings(END, days=3, step_minutes=15)
    for dev, ts, v in readings:
        svc.record(dev, ts, v)
    return svc, readings


class SeedTests(unittest.TestCase):
    def test_enough_synthetic_data(self):
        _, readings = build()
        self.assertGreaterEqual(len(readings), 30)
        self.assertEqual(len(readings), 289 * 7)


class ScenarioTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.svc, cls.readings = build()

    # Сценарий 1: период через полночь возвращает данные двух партиций в порядке DESC
    def test_period_crossing_midnight(self):
        start = datetime(2026, 10, 17, 23, 0)
        end = datetime(2026, 10, 18, 1, 0)
        rows = self.svc.period(THERMO, start, end)
        self.assertEqual(len(rows), 9)  # 23:00 .. 01:00 с шагом 15 мин
        self.assertEqual([r.ts for r in rows], sorted((r.ts for r in rows), reverse=True))
        self.assertEqual({bucket_for(r.ts) for r in rows}, {"2026-10-17", "2026-10-18"})
        asc = self.svc.period(THERMO, start, end, newest_first=False)
        self.assertEqual([r.ts for r in asc], sorted(r.ts for r in asc))

    # Сценарий 2: агрегаты по нескольким партициям совпадают с ручным расчётом
    def test_stats_match_manual(self):
        start, end = END - timedelta(hours=30), END
        vals = [v for d, t, v in self.readings if d == THERMO and start <= t <= end]
        st = self.svc.stats(THERMO, start, end)
        self.assertEqual(st["count"], len(vals))
        self.assertAlmostEqual(st["avg"], sum(vals) / len(vals), places=9)
        self.assertEqual((st["min"], st["max"]), (min(vals), max(vals)))

    def test_stats_empty_period(self):
        st = self.svc.stats(THERMO, datetime(2020, 1, 1), datetime(2020, 1, 2))
        self.assertEqual(st, {"count": 0, "avg": None, "min": None, "max": None})

    # Сценарий 3: last_n собирает записи из нескольких партиций
    def test_last_n_spans_buckets(self):
        rows = self.svc.last_n(THERMO, 60, END)   # сегодня только 49 записей (00:00..12:00)
        self.assertEqual(len(rows), 60)
        self.assertEqual(rows[0].ts, END)
        self.assertEqual([r.ts for r in rows], sorted((r.ts for r in rows), reverse=True))

    def test_current_is_latest(self):
        self.assertEqual(self.svc.current(THERMO).ts, END)

    def test_devices_by_room(self):
        ids = [d.device_id for d in self.svc.devices_in_room(HOME, "kitchen")]
        self.assertEqual(ids, ["fridge-kitchen-01", "power-kitchen-01", "thermo-kitchen-01"])

    def test_partition_size_bounded(self):
        self.assertEqual(self.svc.partition_size(THERMO, "2026-10-17"), 96)  # 24*60/15


class MutationTests(unittest.TestCase):
    def setUp(self):
        self.svc, _ = build()

    # Сценарий 4: порог -> тревога, запись в alerts_by_home_day
    def test_threshold_alert(self):
        ts = END + timedelta(minutes=1)
        a = self.svc.record("fridge-kitchen-01", ts, 12.0)
        self.assertIsNotNone(a)
        self.assertIn("выше порога", a.message)
        self.assertIn(a, self.svc.alerts_for_day(HOME, "2026-10-18"))
        self.assertIsNone(self.svc.record("fridge-kitchen-01", ts + timedelta(minutes=1), 4.0))

    def test_low_threshold_alert(self):
        a = self.svc.record(THERMO, END + timedelta(minutes=2), 5.0)
        self.assertIn("ниже порога", a.message)

    # Сценарий 5: запоздавшее измерение не затирает current
    def test_late_event_keeps_latest(self):
        self.svc.record(THERMO, END - timedelta(hours=5, minutes=7), 99.0)
        self.assertEqual(self.svc.current(THERMO).ts, END)

    # Сценарий 6: UPDATE = upsert по тому же первичному ключу
    def test_upsert_same_pk(self):
        ts = END + timedelta(minutes=5)
        self.svc.record(THERMO, ts, 20.0)
        self.svc.record(THERMO, ts, 21.0)
        rows = self.svc.period(THERMO, ts, ts)
        self.assertEqual([r.value for r in rows], [21.0])

    # Сценарий 7: удаление устройства чистит все таблицы
    def test_delete_device(self):
        n = self.svc.delete_device(THERMO, END - timedelta(days=3), END)
        self.assertEqual(n, 4)
        self.assertIsNone(self.svc.current(THERMO))
        self.assertEqual(self.svc.period(THERMO, END - timedelta(days=3), END), [])
        self.assertNotIn(THERMO, [d.device_id for d in self.svc.devices_in_room(HOME, "living")])

    def test_unknown_device(self):
        with self.assertRaises(KeyError):
            self.svc.record("ghost", END, 1.0)

    def test_new_device_roundtrip(self):
        self.svc.register_device(Device("x-1", HOME, "garage", "t", "temperature", "°C"))
        self.assertIsNone(self.svc.record("x-1", END, 1000.0))   # порогов нет
        self.assertEqual(self.svc.current("x-1").value, 1000.0)


class HourlyBucketTests(unittest.TestCase):
    def test_hour_granularity(self):
        svc, _ = build("hour")
        self.assertEqual(svc.partition_size(THERMO, "2026-10-17T10"), 4)  # 4 записи в час
        rows = svc.period(THERMO, datetime(2026, 10, 17, 9, 30), datetime(2026, 10, 17, 11, 30))
        self.assertEqual(len(rows), 9)
        self.assertEqual(len(svc.last_n(THERMO, 10, END)), 10)


if __name__ == "__main__":
    unittest.main()
