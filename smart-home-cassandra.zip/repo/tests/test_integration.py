"""Интеграционные тесты на живой Cassandra. Запуск:
    RUN_INTEGRATION=1 python -m unittest tests.test_integration -v
Используется отдельный keyspace smart_home_test (создаётся и удаляется тестом).
"""
import os
import unittest
from datetime import datetime, timedelta

from tests import _path  # noqa: F401

TEST_KS = "smart_home_test"


@unittest.skipUnless(os.environ.get("RUN_INTEGRATION") == "1", "set RUN_INTEGRATION=1 and start Cassandra")
class CassandraIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from smart_home.cassandra_repo import CassandraRepository, apply_schema, connect
        from smart_home.seed_data import generate_readings, make_devices
        from smart_home.service import TelemetryService
        cls.cluster, cls.session = connect()
        cls.session.execute(f"DROP KEYSPACE IF EXISTS {TEST_KS}")
        apply_schema(cls.session, TEST_KS)
        cls.session.set_keyspace(TEST_KS)
        cls.svc = TelemetryService(CassandraRepository(cls.session), "day")
        for d in make_devices():
            cls.svc.register_device(d)
        cls.end = datetime(2026, 10, 18, 12, 0)
        for dev, ts, v in generate_readings(cls.end, days=2):
            cls.svc.record(dev, ts, v)

    @classmethod
    def tearDownClass(cls):
        cls.session.execute(f"DROP KEYSPACE IF EXISTS {TEST_KS}")
        cls.cluster.shutdown()

    def test_period_across_partitions_desc(self):
        rows = self.svc.period("thermo-living-01", datetime(2026, 10, 17, 23, 0), datetime(2026, 10, 18, 1, 0))
        self.assertEqual(len(rows), 9)
        self.assertEqual([r.ts for r in rows], sorted((r.ts for r in rows), reverse=True))

    def test_cql_aggregates(self):
        st = self.svc.stats("thermo-living-01", self.end - timedelta(hours=24), self.end)
        self.assertEqual(st["count"], 97)
        self.assertLessEqual(st["min"], st["avg"])
        self.assertLessEqual(st["avg"], st["max"])

    def test_alert_roundtrip(self):
        a = self.svc.record("fridge-kitchen-01", self.end + timedelta(minutes=1), 15.0)
        self.assertIsNotNone(a)
        self.assertTrue(any(x.device_id == "fridge-kitchen-01" and x.value == 15.0
                            for x in self.svc.alerts_for_day("home-1", "2026-10-18")))


if __name__ == "__main__":
    unittest.main()
