# Телеметрия умного дома на Apache Cassandra

СРО по дисциплине «Проектирование и применение NoSQL-технологий», **вариант 12**.
Таблицы по устройству и временному bucket, выборка измерений по периоду, тревоги по порогам, TTL, контроль размера партиций.

## Быстрый старт
```bash
cp .env.example .env
docker compose up -d                 # Cassandra 4.1 (первый запуск 1–2 минуты, ждите healthy)
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python scripts/seed.py --reset       # схема + 7 устройств + 2 023 измерения
python scripts/demo_queries.py       # 10 демонстрационных запросов и CRUD-цикл
```
Без Cassandra демо можно посмотреть на in-memory двойнике: `python scripts/demo_queries.py --memory`.

## Тесты
```bash
python -m unittest discover -s tests -t . -v                      # 22 юнит-теста, Cassandra не нужна
RUN_INTEGRATION=1 python -m unittest tests.test_integration -v    # 3 интеграционных, нужна запущенная Cassandra
```

## Структура
```
src/smart_home/    bucket.py, service.py, cassandra_repo.py, memory_repo.py, demo.py, seed_data.py, schema.cql
scripts/           seed.py, demo_queries.py, make_diagram.py, content.py
tests/             test_bucket.py, test_service.py, test_integration.py
data/              sample_events.csv (100 синтетических событий)
docs/              architecture.png, ADR.md, requirements.md, report.pdf, presentation.pptx
```

## Модель данных (кратко)
| Таблица | Primary key | Запрос |
|---|---|---|
| `measurements_by_device_bucket` | `((device_id, bucket), ts DESC)` | период, последние N, агрегаты |
| `latest_by_device` | `device_id` | текущее состояние |
| `devices_by_room` | `((home_id, room), device_id)` | устройства комнаты |
| `devices_by_id` | `device_id` | поиск устройства |
| `alerts_by_home_day` | `((home_id, day), ts DESC, device_id)` | тревоги за день |

Подробности: `docs/ADR.md`, `docs/requirements.md`, `docs/architecture.png`.

## Конфигурация
`.env` (см. `.env.example`): `CASSANDRA_HOST`, `CASSANDRA_PORT`, `CASSANDRA_KEYSPACE`, `BUCKET_GRANULARITY` (`day`|`hour`). Секретов нет.

## Ограничения
Данные синтетические. Запись в несколько таблиц неатомарна (операции идемпотентны). RF=1 — только для учебного стенда.

## Материалы
- Отчёт: `docs/report.pdf` · Презентация: `docs/presentation.pptx` (и `docs/presentation.pdf`)
- GitHub: _вставьте ссылку на репозиторий_
